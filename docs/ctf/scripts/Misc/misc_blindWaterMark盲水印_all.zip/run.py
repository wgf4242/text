# 2张图改名为 1.png 2.png
# 1张图改名为 1.png
py2 = r'D:\wgf\.pyenv\pyenv-win\versions\2.7.18\python.exe'
find_paths = [r'D:\bin', r'F:\downloads\@CTF\bwm']

import os

file1 = '1.png'
file2 = '2.png' if os.path.exists('2.png') else None
ext = file1.split('.')[1]
len_lst = len(list(filter(lambda x: x, [file1, file2])))  # filter True
tools_dir = ''
for i, path in enumerate(find_paths):
    if os.path.exists(path + r'\Misc_BlindWatermark.jar'):
        tools_dir = path
        break
print(tools_dir)
i = 0


def ni():
    global i
    i += 1
    return i


def out():
    return f'out{ni()}.{ext}'


if file1 and file2:
    os.system(f'python bwmpy3.py decode {file1} {file2} out{ni()}.png')
    os.system(f'python bwmpy3.py decode {file1} {file2} out{ni()}.png --oldseed --alpha 10')
    os.system(f'{py2} bwm.py decode {file1} {file2} out{ni()}.png --oldseed --alpha 10')
    os.system(f'{py2} pinyubwm.py --original {file1} --image {file2} --result out{ni()}.png')
if len_lst == 1:
    os.system(f'python fourier_fft_傅利叶.py {file1} out{ni()}.{ext}')
    os.system(fr'java -jar {tools_dir}\Misc_BlindWatermark.jar decode -c "{file1}" {out()}')
    os.system(f'Misc_BlindWatermark_隐形水印工具.exe')
