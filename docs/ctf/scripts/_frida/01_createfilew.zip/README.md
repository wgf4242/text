https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew

frida-trace -i "CreateFileW" notepad.exe