export function log(message: string): void {
    console.log(message);
}
