#include <stdio.h>
#include "string.h"

int main() {
    // setbuf(stdout, NULL);
    char inst1[] = "A123456";
    char inst2[] = "A555555";
    int i = 0;
    if (strcmp(inst1, inst2) == 0) {
        puts("two string is same");
        scanf("%d", &i);
        printf("done, %d", i);
    }
    return 0;
}