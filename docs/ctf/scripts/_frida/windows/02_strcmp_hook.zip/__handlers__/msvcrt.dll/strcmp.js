
{

  onEnter(log, args, state) {
    log('strcmp(), args  3 is', typeof args);
    log('-start')
    log('val1: ' + Memory.readCString(args[0]));
    log('val2: ' + Memory.readCString(args[1]));
    log('-end-');
  },
  onLeave(log, retval, state) {
    log('-hook retval to equal');
    retval.replace(0);
  }
}
