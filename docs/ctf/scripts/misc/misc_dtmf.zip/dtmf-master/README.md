修改 dtmf-decoder.py 96行
py2 dtmf-decoder.py

DTMF
====

This is a collection of useful infos for DTMF .   

http://en.wikipedia.org/wiki/Goertzel_algorithm  
http://www.black-aura.com/blog/2011/12/10/python-implementation-of-the-goertzel-algorithm-dtmf-decod  
http://xoomer.virgilio.it/sam_psy/psych/sound_proc/sound_proc_python.html  
http://www.douban.com/group/topic/6109154/  
https://bitbucket.org/blackaura/python-dtmf-decoder  
http://www.mediacollege.com/audio/tone/dtmf.html  
http://gitorious.org/dtmf-generator


FSK
=====
http://en.wikipedia.org/wiki/Frequency-shift_keying  
http://code.google.com/p/arms22/  
hijack: 
-------
  http://web.eecs.umich.edu/~prabal/projects/hijack/  
  http://code.google.com/p/hijack-main/  
  https://github.com/ab500/hijack-infinity.git  
  http://www.seeedstudio.com/depot/hijack-development-pack-p-865.html  
  http://www.creativedistraction.com/demos/sensor-data-to-iphone-through-the-headphone-jack-using-arduino/  

