> **Warning:** This repository is not maintained anymore

# VeraCracker
Veracrypt Password Cracker <br />
This script will go through a list of passwords and try these against the specified volume. If succeeded, it will mount the partition. 

**Note:** This project is currently only working under **Python 3.x** on **Windows** and Linux systems. <br />
**Note:** **No dependencies** are needed, but **VeraCrypt has to be installed**

## Disclaimer
This tool is for educational purposes only and is not intended to be put into practise unless you have authorised access to the system you are trying to break into.

## License
This software is licensed under the "Original BSD License".
```
  (C) 2015  NorthernSec          https://github.com/NorthernSec
  (c) 2015  Pieter-Jan Moreels   https://github.com/pidgeyl
```
