f = open('xx.py', 'rb')
txt = f.read()
print(txt)