import subprocess
import fcntl
import os
import sys
import time
import binascii

if len(sys.argv) != 2:
    print("Usage: python3 script.py <input_string>")
    sys.exit(1)

input_string = sys.argv[1]  
executable = './easy_vm'
process = subprocess.Popen(executable, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
fd = process.stdout.fileno()
fl = fcntl.fcntl(fd, fcntl.F_GETFL)
fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)

try:
    while True:
        input_data = f'{input_string}\n'.encode()
        process.stdin.write(input_data)
        process.stdin.flush()
        try:
            output = process.stdout.read()
            if output:
                hex_output = binascii.hexlify(output)
                print(hex_output.decode()[36:78])
                break
        except IOError:
            pass 
finally:
    process.kill()
