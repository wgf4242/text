import subprocess
import string
import time

target_output = "d9e1d5c9f8b8d5fdd3f2fdd0b6cfe4f68bddd3f2"
characters = ''.join(c for c in string.printable if c not in string.whitespace)
input_value = "abbaaaaaaaaaaaaaaaaa"
def get_output(input_val):
    try:
        result = subprocess.run(['python3', 'bianli_exp.py', input_val], capture_output=True, timeout=10)
        return result.stdout.decode().strip()
    except subprocess.TimeoutExpired:
        print(f"Timeout expired for input '{input_val}'. Retrying...")
        return get_output(input_val) 

for i in range(len(input_value)):
    for char in characters:
        test_value = list(input_value)
        test_value[i] = char
        test_value = ''.join(test_value)
        output = get_output(test_value)
        print(f"Trying with input '{test_value}' -> Output: '{output}'")
        if output[i*2:(i+1)*2].lower() == target_output[i*2:(i+1)*2]:
            input_value = test_value
            print(f"Character at position {i+1} found: '{char}' -> Current input: {input_value}")
            break

print(f"Final input value: {input_value}")
